#ifndef __HT_RELGPIO_H
#define __HT_RELGPIO_H
#include "sys.h"
#define REL1  PBout(3) 
#define REL2  PBout(4)
#define REL3  PBout(5)
#define REL4  PBout(6)
#define REL5  PBout(7)

void REL_GPIO_Init(void);
 
#endif

