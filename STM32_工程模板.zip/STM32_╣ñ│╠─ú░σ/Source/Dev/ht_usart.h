#ifndef __HT_USART_H
#define __HT_USART_H
#include "config.h"	
#define USART1_RXBUF_SIZE 256
#define USART1_BAUD 115200
extern  u8 RecCh;

void init_usart1(u32 USART1_BaudRate);
void init_usart2(u32 USART2_BaudRate);
void usart_send_byte(USART_TypeDef* USARTx,u8 ch);
void usart_send_string(USART_TypeDef* USARTx,u8 str[]);




#endif
       
