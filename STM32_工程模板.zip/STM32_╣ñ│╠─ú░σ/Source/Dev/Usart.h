#ifndef __USART_H__
#define __USART_H__

#define USART1_RXBUF_SIZE 256
#define USART1_BAUD 115200


void UsartInit(void);
void UsartSendString(USART_TypeDef* USARTx,u8 *str);
void UsertSendByte(USART_TypeDef* USARTx,u8 ch);
unsigned char USART1_RecProcess(void);

#endif
       




