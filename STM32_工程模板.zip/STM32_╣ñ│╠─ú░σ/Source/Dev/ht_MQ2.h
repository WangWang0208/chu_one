#ifndef _HT_MQ2_H
#define _HT_MQ2_H


#include "config.h"


#define RL 5 //RL����ֵ
#define CAL_PPM  20 //У׼�����е�ppm
void Adc_Init(void);
u16 Get_adc(u8 ch);
u16 Get_Adc_Average(u8 ch,u8 times);
void MQ2_cumlate(float RS);
float MQ2_GetPPM(void);
float MQ2_control(void);

#endif

