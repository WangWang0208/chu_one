#include "config.h"
#include "EXTI.h"

//��ʼ��Ҫ����EXTI��GPIO��
//��ʼ��EXTI���ڲ����ж�
//��ʼ��NVIC�����ڴ�������
//��д�жϷ�����
void ExitGpioInit(void)//IO�ڵĳ�ʼ��
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA ,ENABLE);
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE| RCC_APB2Periph_AFIO ,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPD;//ģʽΪ��������
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_6|GPIO_Pin_9;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_IPU;//ģʽΪ��������
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_3|GPIO_Pin_4;
	GPIO_Init(GPIOE,&GPIO_InitStruct);
	//IO�ں��ж��ߵ����ú���
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource0);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource3);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOE, GPIO_PinSource4);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource6);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource9);
}
void ExitModeInit(void)//ģʽ�ĳ�ʼ��(�жϺ�����أ�
{
	EXTI_InitTypeDef EXTI_InitStruct;
  EXTI_InitStruct.EXTI_Line= EXTI_Line0;
	EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Rising;//��������
	EXTI_InitStruct.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
  EXTI_InitStruct.EXTI_Line= EXTI_Line3;
	EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Falling;//��������
	EXTI_InitStruct.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
	EXTI_InitStruct.EXTI_Line= EXTI_Line4;
	EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Falling;//��������
	EXTI_InitStruct.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
  EXTI_InitStruct.EXTI_Line= EXTI_Line6;
	EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Rising;//��������
	EXTI_InitStruct.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
  EXTI_InitStruct.EXTI_Line= EXTI_Line9;
	EXTI_InitStruct.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger=EXTI_Trigger_Rising;//��������
	EXTI_InitStruct.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStruct);
	
}
void ExtiNVICInit(void)//�жϷּ���ʼ��
{
	NVIC_InitTypeDef NVIC_InitStruct;
	
	NVIC_InitStruct.NVIC_IRQChannel=EXTI0_IRQn;
	//��stm32f10x.h��
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	 NVIC_Init(&NVIC_InitStruct);
	
	NVIC_InitStruct.NVIC_IRQChannel=EXTI3_IRQn;
	//��stm32f10x.h��
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=0;//��߼�
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	 NVIC_Init(&NVIC_InitStruct);
	
		NVIC_InitStruct.NVIC_IRQChannel=EXTI4_IRQn;
	//��stm32f10x.h��
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	 NVIC_Init(&NVIC_InitStruct);
	 
	 	NVIC_InitStruct.NVIC_IRQChannel=EXTI9_5_IRQn;
	//��stm32f10x.h��
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	 NVIC_Init(&NVIC_InitStruct);
}
void ExtiInit(void)
{
	ExitGpioInit();
	ExitModeInit();
	ExtiNVICInit();
	
}
void EXTI0_IRQHandler (void)//�ж����������ļ���
{
	//�жϱ�־λ���ж�
	if(EXTI_GetITStatus(EXTI_Line0)==SET)
	{
		Beep=!Beep;
		EXTI_ClearITPendingBit(EXTI_Line0);
	}

}
void EXTI3_IRQHandler (void)
{
	if(EXTI_GetITStatus(EXTI_Line3)==SET)
	{
		printf("This is EXTI3!\r\n");
		EXTI_ClearITPendingBit(EXTI_Line3);
	}
	
}
void EXTI4_IRQHandler (void)
{
	if(EXTI_GetITStatus(EXTI_Line4)==SET)
	{
		printf("This is EXTI4!\r\n");
		EXTI_ClearITPendingBit(EXTI_Line4);
	}
	
}
void  EXTI9_5_IRQHandler (void)
{
if(EXTI_GetITStatus(EXTI_Line6)==SET)
	{
		LED0=!LED0;
		EXTI_ClearITPendingBit(EXTI_Line6);
	}
	if(EXTI_GetITStatus(EXTI_Line9)==SET)
	{
		LED1=!LED1;
		EXTI_ClearITPendingBit(EXTI_Line9);
	}
}
