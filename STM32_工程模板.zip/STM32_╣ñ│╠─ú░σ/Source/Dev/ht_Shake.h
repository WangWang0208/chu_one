#ifndef __Shake_H_
#define __Shake_H_
 
void Shake_Init(void);
 
#endif
