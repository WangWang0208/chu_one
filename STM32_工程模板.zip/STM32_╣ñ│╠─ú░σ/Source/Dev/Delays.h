#ifndef __DELAYS_H
#define __DELAYS_H

void Delays_us(uint32_t us);
void Delays_ms(uint32_t ms);
void Delays_s(uint32_t s);
 
#endif
