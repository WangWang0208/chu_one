#ifndef __ADC_H__
#define __ADC_H__

void MyAdc_Init(void);
u16 Get_Adc(void);
	
#endif
