#ifndef __USART3_H__
#define __USART3_H__

void init_usart3(u32 USART2_BaudRate);


#endif

