#ifndef _LCD_PIC_H
#define _LCD_PIC_H

extern const unsigned char gImage_1[3200];

#endif


