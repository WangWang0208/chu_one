#ifndef __BEEP_H__
#define __BEEP_H__

#define Beep PCout(1)
void Beep_GPIO_Init(void);



#endif

