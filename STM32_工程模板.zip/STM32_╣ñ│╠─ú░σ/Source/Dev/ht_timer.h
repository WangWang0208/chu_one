#ifndef __TIMER_H
#define __TIMER_H
#include "config.h"
extern u16 times;

void Timer3_Init(u16 arr,u16 psc);
void Timer4_Init(u16 arr,u16 psc);
void TIM5_PWM_Init(u16 my_psc,u16 my_arr);

void TIM3_ENABLE_30S(void);
void TIM3_ENABLE_2S(void);
void TIM2_ENABLE_1S(void);

#endif
