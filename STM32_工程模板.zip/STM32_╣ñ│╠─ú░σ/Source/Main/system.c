//�������õ��ĺ���
#include "config.h"
#include "system.h"
#define ATaskPeriod 100
#define BTaskPeriod 150
#define CTaskperiod 200
#define ButtonTaskPeriod 10
#define USART1RecProcessPeriod 15

//void Delay_ms(u16 ms)
//{
//	u16 i=0;
//	while(ms--)
//	{
//		for(i=0;i<11000;i++);//1ms=11000
//	}
//}

void SysInit(void)
{
	CPU_INT_ENABLE();//�����жϿ���
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//���жϷּ� misc.c 96
	LED_GPIO_Init();//��ʼ��
	SystickInit();
	TaskInit();
	UsartInit();
	ExtiInit();
  Timer2_Init(7199,999);
	Timer3_Init(0,7999);
	Timer1_Init(0,7199);
//	MyAdc_Init();
}

////�����ʼ���ĺ���
void TaskInit(void)
{
	ATaskTimer=ATaskPeriod;
	BTaskTimer=BTaskPeriod;
	CTaskTimer=	CTaskperiod;
	ButtonTaskTimer=ButtonTaskPeriod;
	USART1RecProcessTimer=USART1RecProcessPeriod;
}
////��ʱ��ʵ��LED��ȡ���ĺ���

void ATask(void)
{
	if(ATaskTimer)
		return;
	  LED0=!LED0;
	ATaskTimer=ATaskPeriod;//���¶���
//	u16 ADC_value=0;
//	static u8 ADC_ConvTimes=0;
//	static u16 ADC_Sum=0;
//	 ADC_value=Get_Adc();
//	ADC_ConvTimes++;
//	ADC_Sum+=ADC_value;
//	if(ADC_ConvTimes==10)
//	{
//		ADC_ConvTimes=0;
//		 ADC_value=ADC_Sum/10;
//		ADC_Sum=0;
//		printf("The adc result:%d\r\n", ADC_value);
//	}
//	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
}
void BTask(void)
{
	if(BTaskTimer)
		return;
	 LED1=!LED1;
	BTaskTimer=BTaskPeriod;//���¶���
}
void CTask(void)
{
	if(CTaskTimer)
		return;
	CTaskTimer=CTaskperiod;
	UsartSendString(USART1,"CTask is running!\r\n");
	printf("Hello!\r\n");
}
void ButtoTask(void)
{
	u8 Key_Value=0;
	Key_Value=Key_scanf();
switch (Key_Value)
{
	case Key_Up_value:
		LED0=!LED0;
	  break;
	case Key0_value:
	  LED1=!LED1;
  	break;
	case Key1_value:
		LED0=!LED0;
	  LED1=!LED1;
  	break;
	case Key2_value:
		break;
	default:
		break;
}
}
void USART1RecProcessTask(void)
{
	if(USART1RecProcessTimer)return;
	USART1RecProcessTimer=USART1RecProcessPeriod;
//	USART1_RecProcess();
}
//ִ������ĺ���,����Ҫ����
void TaskRun(void)
{
	ATask();
	BTask();
	//CTask();
 // ButtoTask();
	USART1RecProcessTask();
}
