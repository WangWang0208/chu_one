#ifndef _HT_SYSTEM_H
#define _HT_SYSTEM_H

void SysInit(void);
void ATask(void);
void BTask(void);
void CTask(void);
void DTask(void);
void auto_mode(void);

#endif
