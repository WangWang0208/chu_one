#ifndef __CONFIG_H__
#define __CONFIG_H__

#define CPU_INT_ENABLE()  {__set_PRIMASK(0);}//�궨�� �����жϿ���
#define CPU_INT_DISABLE() {__set_PRIMASK(1);}//�ж��ܿ���cm3

typedef enum
{
FALSE=0,TRUE=!FALSE
}BOOL;

#include "stm32f10x.h"
#include "main.h"
#include "string.h"
#include "LED.h"
#include "stdio.h"
#include "system.h"
#include "systick.h"
#include "RemapGPIO.h"
#include "key.h"
//#include "Usart.h"
#include "EXTI.h"
#include "Timer.h"
#include "math.h"
#include "usart1.h"
#include "usart2.h"
//��̩��ذ��
#include "Delays.h"
#include "ht_delay.h"
#include "delay2.h"
#include "ht_timer.h"
#include "ht_system.h"

#include "ht_usart.h"
#include "sys.h"
#include "ht_human.h"
#include "ht_BH.h"
#include "ht_IIC.h"
#include "ht_Shake.h"
#include "ht_MQ2.h"
#include "LCD_pic.h"
#include "ht_LCD.h"
#include "ht_LcdInit.h"
#include "Lcdfront.h"
#include "BEEP.h"
#include "dht11.h"
#include "Delays.h"
#include "Sys_DHT11.h"
#include "Delay.h"
#include "dateup.h"
#include "wifi.h"
#include "mqtt.h"
#include "iwdg.h"
#include "datedown.h"
#include "switch.h"
#include "usart3.h"


#include "utils_hmac.h"
#include "utils_md5.h"
#include "utils_sha1.h"
 

#endif
