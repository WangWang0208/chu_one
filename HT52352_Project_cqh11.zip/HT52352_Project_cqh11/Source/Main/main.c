/*********************************************************************************************************//**
 * @file    IP/Example/main.c
 * @version $Rev:: 971          $
 * @date    $Date:: 2016-09-08 #$
 * @brief   Main program.
 *************************************************************************************************************
*/
// <<< Use Configuration Wizard in Context Menu >>>

/* Includes ------------------------------------------------------------------------------------------------*/

#define  MAIN_CONFIG
#include "config.h"

//extern unsigned int http_response_len;
//extern unsigned char  http_response[512];	
//extern char HTTP_Buf[];
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/

//	SysInit();
//	
//	while(1)
//	{
//		//task_run();
//		USART_SendData(HT_USART0, 'A');
//	}
int main(void)
{

  SysInit();
  while (1)
  {
	  TaskRun(); 
		
//		 GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_7,SET);
//		Systick_Delay_ms(50);
//		GPIO_WriteOutBits(HT_GPIOA,GPIO_PIN_7,RESET);
//		Systick_Delay_ms(50);	
		
		//auto_mode();
		//ATask();
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
		//auto_mode();

  }

}




