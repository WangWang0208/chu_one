
#ifndef __BH_H_
#define __BH_H_

#include "config.h"
#include "stdio.h"

#define	  SlaveAddress   0x46

extern u8 BUF[10]; 


void Write_BH1750(u8 REG_Address);   
void Read_BH1750(void);              
void Start_BH1750(void);             //�ɼ�����
int read_bh1750(void);

#endif

