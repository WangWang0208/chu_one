#ifndef _TOTALY_H
#define _TOTALY_H

#include "config.h"


void Send_onenet(void);
void Send_HIM(void);
void Send_key(unsigned char key);
#endif

