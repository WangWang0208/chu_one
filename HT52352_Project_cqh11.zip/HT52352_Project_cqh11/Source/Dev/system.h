#ifndef _SYSTEM_H
#define _SYSTEM_H

void SysInit(void);


#endif
