#ifndef __LED_H__
#define __LED_H__	 

#include "ht32.h"

#define LED1_GPIO_ID                (GPIO_PC)
#define LED1_GPIO_PIN               (GPIO_PIN_14)
#define LED1_AFIO_MODE              (AFIO_FUN_GPIO)
#define LED1_CLK(CK)                (CK.Bit.PC)
#define LED1                        (HT_GPIOC)


#define LED2_GPIO_ID                (GPIO_PC)
#define LED2_GPIO_PIN               (GPIO_PIN_15)
#define LED2_AFIO_MODE              (AFIO_FUN_GPIO)
#define LED2_CLK(CK)                (CK.Bit.PC)
#define LED2                        (HT_GPIOC)

void Led_Init(void);	//Led��ʼ��	
void LEDToggle(HT_GPIO_TypeDef* GPIO_PORT,u16 GPIO_PIN_n);


#endif

























