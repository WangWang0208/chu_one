#ifndef _MQ2_H__
#define _MQ2_H__

#include "config.h"

//#if defined(USE_HT32F52342_52_SK)
	#define HTCFG_VR_GPIO_ID   				  (GPIO_PA)
	#define HTCFG_VR_AFIO_PIN   				(AFIO_PIN_6)
	#define HTCFG_VR_ADC_CH     				(ADC_CH_6)

	



void Adc_Init(void);
void ADC_IRQHandler(void);
float MQ2_GetPPM(void);
float MQ2_control(void);

#endif



