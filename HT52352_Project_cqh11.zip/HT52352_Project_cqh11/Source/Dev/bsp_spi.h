#ifndef _SPI_H
#define _SPI_H
#include "ht32.h"
void SPI1_Init(void);
unsigned char SPI1_ReadWrite(unsigned char  dat);

#endif

