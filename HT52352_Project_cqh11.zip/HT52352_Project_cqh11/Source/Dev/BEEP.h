#ifndef _BEEP_H_
#define _BEEP_H_

void Beep_GPIO_Init(void);


#endif
