#ifndef _Shake_H_
#define _Shake_H_

void Shake_Init(void);

	
#endif
