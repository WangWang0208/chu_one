#include "bsp_BFTM.h"

extern int compare;
void BF_TIM_int(void) 
{

	
	CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  CKCUClock.Bit.BFTM0      = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

	CKCU_SetPeripPrescaler(CKCU_PCLK_BFTM0, CKCU_APBCLKPRE_DIV8);
	
	
  NVIC_EnableIRQ(BFTM0_IRQn);

  BFTM_SetCompare(HT_BFTM0, SystemCoreClock/8);//1��һ��
  BFTM_SetCounter(HT_BFTM0, 0);
  BFTM_IntConfig(HT_BFTM0, ENABLE);
  BFTM_EnaCmd(HT_BFTM0, ENABLE);
	


}



/*********************************************************************************************************//**
 * @brief   This function handles BFTM interrupt.��ʱ���ж�
 * @retval  None
 ************************************************************************************************************/
void BFTM0_IRQHandler(void)
{ 

  if(BFTM_GetFlagStatus(HT_BFTM0)==SET)
	{
		MQ2_control();
	}
  BFTM_ClearFlag(HT_BFTM0);
} 

