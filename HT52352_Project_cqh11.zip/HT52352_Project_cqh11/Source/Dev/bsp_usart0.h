#ifndef __USART0_H
#define __USART0_H

#include "ht32.h"

//extern struct rt_ringbuffer usart0_recv_ring_buf;//����uart1���ջ��ζ�������

//void Usart0_Init(int baudrate);
//void Usart0_SendSring(char* str);
////unsigned char Usart0_RecProcess(void);



//#define USART_GPIO_GROUP             (GPIO_PA)
//#define USART0_TX_PIN                 (AFIO_PIN_2)
//#define USART0_RX_PIN                 (AFIO_PIN_3)
//#define USART_AFIO_MODE              (AFIO_FUN_USART_UART) //ģʽ���ã�Ĭ��ģʽ��AFIO_MODE_DEFAULT ��AFIO_MODE_1~15��Ӧģʽ1~15
//#define COM0_PORT                    (HT_USART0)

//void USART0_Configuration(void);
void USART0_init(void);
void USART0_IRQHandler(void);


#endif
