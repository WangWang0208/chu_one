#include "bsp_led.h"


void Led_Init(void)
{ 
	CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
	
	LED1_CLK(CKCUClock) = 1;  //CKCUClock.Bit.PC = 1;
	LED2_CLK(CKCUClock) = 1;  

	CKCUClock.Bit.AFIO  = 1;
	CKCU_PeripClockConfig(CKCUClock, ENABLE);
	
	/* Configure LED1, LED2, LED3 pins as output function                                                     */

	/* Configure AFIO mode of output pins                                                                     */
	AFIO_GPxConfig(LED1_GPIO_ID, LED1_GPIO_PIN, AFIO_FUN_GPIO);
	AFIO_GPxConfig(LED2_GPIO_ID, LED2_GPIO_PIN, AFIO_FUN_GPIO);


	/* Configure GPIO direction of output pins                                                                */
	GPIO_DirectionConfig(LED1, LED1_GPIO_PIN, GPIO_DIR_OUT);
	GPIO_DirectionConfig(LED2, LED2_GPIO_PIN, GPIO_DIR_OUT);

  GPIO_WriteOutBits(LED1, LED1_GPIO_PIN,   SET);//LED1Ϩ��
	GPIO_WriteOutBits(LED2, LED2_GPIO_PIN,   SET);//LED2Ϩ��
}

void LEDToggle(HT_GPIO_TypeDef* GPIO_PORT,unsigned short GPIO_PIN_n)
{
  GPIO_PORT->DOUTR ^= GPIO_PIN_n;
}









