#ifndef __EXI_H__
#define __EXI_H__	 
#include "ht32.h"

extern u8 ov_sta;	//֡�жϱ��
void EXTIX_Init(void);	//�ⲿ�жϳ�ʼ��	
void EXTI8_Init(void);	


#endif

























