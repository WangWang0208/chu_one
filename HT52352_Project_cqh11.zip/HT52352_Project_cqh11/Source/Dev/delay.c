#include "config.h"
#include "delay.h"
void Systick_Delay_ms(u32 ms)
{
	u32 i;
	
 
	SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);      
	SYSTICK_SetReloadValue(SystemCoreClock / 8 / 1000); 
	SYSTICK_IntConfig(DISABLE);                        
 
 
	SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
	SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
	
	for( i = 0;i < ms;i++ )
	{
		while( !( (SysTick->CTRL) & (1<<16) ) ); 
	}
 
 
	SYSTICK_CounterCmd(SYSTICK_COUNTER_DISABLE);
 
	SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
}
 
void Systick_Delay_us(u32 us)
{
	u32 i;
	
 
	SYSTICK_ClockSourceConfig(SYSTICK_SRC_STCLK);      
	SYSTICK_SetReloadValue(SystemCoreClock / 8 / 1000000); 
	SYSTICK_IntConfig(DISABLE);                        
 
 
	SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
	SYSTICK_CounterCmd(SYSTICK_COUNTER_ENABLE);
 
	for( i = 0;i < us;i++ )
	{
		while( !( (SysTick->CTRL) & (1<<16) ) ); 
	}
 
 
	SYSTICK_CounterCmd(SYSTICK_COUNTER_DISABLE);
 
	SYSTICK_CounterCmd(SYSTICK_COUNTER_CLEAR);
}
