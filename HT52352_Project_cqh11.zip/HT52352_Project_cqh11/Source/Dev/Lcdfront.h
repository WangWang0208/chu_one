#ifndef __LCDFONT_H
#define __LCDFONT_H 	   

extern const unsigned char ascii_3216[][64];

typedef struct 
{
	unsigned char Index[2];	
	unsigned char Msk[128];
}typFNT_GB32; 

extern const typFNT_GB32 tfont32[100];
#endif
