#ifndef __DELAY_H_
#define __DELAY_H_

void Systick_Delay_ms(u32 ms);
void Systick_Delay_us(u32 us);


#endif
