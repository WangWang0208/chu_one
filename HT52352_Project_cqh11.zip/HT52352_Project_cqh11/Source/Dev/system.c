#include "config.h"
#include "system.h"

#define MSG_POOL_CAPACITY 128
//static uint8_t msg_pool[MSG_POOL_CAPACITY];//���ζ�����Ϣ��


void SysInit (void)
{
//	Led_Init();
	  SysTickInit();
	//RETARGET_Configuration();//Printf��������ض���PA4:TX,PA5:RX��
//Usart1_Init(9600);//(PA4:TX,PA5:RX)
// // Usart0_Init(9600);//(PA2:TX,PA3:RX)
//	BF_TIM_int();
   	SCTM_Configuration(5000,0);
//	GTCM_Configuration();
//	//rt_ringbuffer_init(&msg_ring_buf, msg_pool, MSG_POOL_CAPACITY); //��ʼ����Ϣ���ζ���
	Beep_GPIO_Init();
	LCD_Init();
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	dou_dht11_init();

//	task_init();//�����ʼ��
//	//USART_Configuration();
//	//USART1_init();
//	//USART0_Configuration();
	USART0_init();
	
	UART0_init();
	Start_BH1750();
//	//USART1_init();

	Infrared_Init();
	Shake_Init();
	Adc_Init();
 

 
}


