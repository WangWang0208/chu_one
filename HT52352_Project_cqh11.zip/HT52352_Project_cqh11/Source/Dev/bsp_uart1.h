#ifndef __UART1_H__
#define __UART1_H__

#include "ht32.h"

extern u8 RecCh;
//extern struct rt_ringbuffer uart1_recv_ring_buf;//����uart1���ջ��ζ�������

//void Usart1_Init(int baudrate);
//void Usart1_SendSring(char* str);
////unsigned char Uart1_RecProcess(void);
//#define USART_GPIO_GROUP             (GPIO_PA)
//#define USART_TX_PIN                 (AFIO_PIN_4)
//#define USART_RX_PIN                 (AFIO_PIN_5)
//#define USART_AFIO_MODE              (AFIO_FUN_USART_UART) //ģʽ���ã�Ĭ��ģʽ��AFIO_MODE_DEFAULT ��AFIO_MODE_1~15��Ӧģʽ1~15
//#define COM1_PORT                    (HT_USART1)

//void USART_Configuration(void);
//void UART1_init(void);
//void UART1_IRQHandler(void);
void UART0_init(void);
void UART0_IRQHandler(void);
void Usart_Sendbyte(HT_USART_TypeDef* USARTx, u8 data);
void Usart_SendArray(HT_USART_TypeDef* USARTx, u8 *array,u8 num);
void Usart_SendStr(HT_USART_TypeDef* USARTx, uint8_t *str);
//void USART_Tx(const char* TxBuffer, u32 length);
//void USART_Rx(const char* RxBuffer, u32 length);
#endif



