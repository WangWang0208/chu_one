#ifndef __task_H__
#define __task_H__

#include "ht32.h"
#ifdef __cplusplus
 extern "C" {
#endif

typedef struct timer_parameter {
    void (*timeout_cb)(void); 
	uint32_t timeout;
	uint32_t repeat;
}task_timer_parameter;


int task_init(void);
int task_run(void);

void auto_mode(void);
void ATask(void);
void BTask(void);
void CTask(void);
void DTask(void);
void TaskRun(void);
//void ATask(void);

#ifdef __cplusplus
}
#endif


#endif
/*****************************END OF FILE*********************************/
